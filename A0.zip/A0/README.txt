Compilation:

No changes to default premake4/make combination:
cd cs488
premake4 gmake
make
cd A0
premake4 gmake
make
./A0

Lab Machine gl15 was used.



Manual:

No comments.
