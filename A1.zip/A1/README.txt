Compilation:

No changes to default premake4/make combination:
cd cs488
premake4 gmake
make
cd A1
premake4 gmake
make
./A1

Lab Machine gl15 was used.



Manual:

All required features were implemented.  In addition, line segments outlined the cubes to help show depth and position of the bars (as opposed to solid colour bars).
